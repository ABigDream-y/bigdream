<template>
	<div class="mod-plan__planDetail-edit-compare" style="height: 100%;">
		<div class="null" v-if="dataForm.status == 1">方案[<span title="点击跳转详情" style="color: #0BB2D4;text-decoration: underline;cursor:pointer;" @click="detailHandle(dataForm)">{{dataForm.name}}</span>]暂未生成，请先生成教学计划^_^</div>
		<div class="compare-wrap" v-else>
			<div class="left">
				对比-左边
			</div>
			<div class="right">
				对比-右边
			</div>
		</div>
	</div>
</template>

<script lang="ts">
	import baseService from "@/service/baseService";
	import { IObject } from "@/types/interface";
	import useView from "@/hooks/useView";
	import { defineComponent, reactive, toRefs } from "vue";
	import AddOrUpdate from "./groupcourse-add-or-update.vue";
	import { registerDynamicToRouterAndNext } from "@/router";
	export default defineComponent({
		components: {
			
		},
		props: {
			
		},
		setup() {
			const state = reactive({
				dataForm: {
					id: "",
					grade: "",
					institute: "",
					instituteNo: "",
					major: "",
					majorDirection: "",
					name: "",
					eduSystem: "",
					startGrade: "",
					startTerm: "",
					termType: "",
					courseType: "",
					scoreMin: "",
					academicDegree: "",
					trainObjective: "",
					readingRequirements: "",
					programFeatures: "",
					majorDisciplines: "",
					mainCourses: "",
					mainProfessionalExperiments: "",
					status: 0,
					creator: "",
					createDate: "",
					updater: "",
					updateDate: ""
				} as IObject
			});
			return { ...useView(state), ...toRefs(state) };
		},
		watch: {
			
		},
		methods: {
			init(data) {
				this.dataForm = data;
				console.log(this.dataForm);
			},
			detailHandle(data : IObject) {
				console.log("data", data);
				const routeParams = {
					routeName: `programme-casedetail__${data.id ? data.id : 0}`,
					title: `${data.name} - 详情`,
					path: `/programme/casedetail`,
					query: {
						id: data.id ? data.id : 0,
						_mt: `${data.name} - 详情`
					}
				};
				registerDynamicToRouterAndNext(routeParams);
			}
		}
	});
</script>

<style scoped lang="scss">
	.mod-left-card {
		width: 100%;
		min-height: calc(100vh - 50px - 40px - 30px - 20px - 55px - 42px - 20px);

		.group-title {
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin-top: 0;
		}

		.group-item {
			width: 100%;
			padding: 10px;
			cursor: pointer;
			display: flex;
			align-items: center;
			justify-content: space-between;
		}

		.active {
			background-color: rgba(62, 142, 247, 0.2);
			color: #3E8EF7;
		}

	}
	.null {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 100%;
		height: 100%;
		font-size: 20px;
		font-weight: 100;
		color: grey;
	}
	.compare-wrap {
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: row;
		justify-content: center;
		align-items: flex-start;
		.left {
			flex: 1;
		}
		.right {
			flex: 1;
		}
	}
</style>