<template>
	<div class="mod-plan__planDetail-edit-detail" style="height: 100%;">
		<div class="null" v-if="dataForm.status == 1">方案[<span title="点击跳转详情"
				style="color: #0BB2D4;text-decoration: underline;cursor:pointer;"
				@click="detailHandle(dataForm)">{{dataForm.name}}</span>]暂未生成，请先生成教学计划^_^</div>
		<div v-else>
			<el-form :inline="true" ref="form" :model="dataForm" @keyup.enter="getDataList()">
				<el-form-item v-if="hasPermission('plan:planrecord:save')">
					<el-button type="primary" @click="editHandle()">{{ $t("add") }}</el-button>
				</el-form-item>
				<el-form-item v-if="hasPermission('plan:planrecord:delete')">
					<el-button type="danger" @click="deleteHandle()">{{ $t("deleteBatch") }}</el-button>
				</el-form-item>
				<el-form-item v-if="hasPermission('plan:planrecord:save')">
					<el-button type="warning" @click="multiAuditHandle()">批量审核</el-button>
				</el-form-item>
				<el-form-item v-if="hasPermission('plan:planrecord:export')">
					<el-button type="info" @click="exportHandle()">{{ $t("export") }}</el-button>
				</el-form-item>
			</el-form>
			<el-table v-loading="dataListLoading" :data="dataList" border
				@selection-change="dataListSelectionChangeHandle" style="width: 100%">
				<el-table-column type="selection" header-align="center" align="center" width="50"></el-table-column>
				<el-table-column label="序号" header-align="center" align="center">

				</el-table-column>
				<el-table-column prop="code" label="课程号" header-align="center" align="center"
					width="120"></el-table-column>
				<el-table-column prop="name" label="课程名称" header-align="center" align="center"
					width="200"></el-table-column>
				<el-table-column prop="nameEn" label="学分" header-align="center" align="center"
					width="200"></el-table-column>
				<el-table-column prop="unit" label="学时" header-align="center" align="center"
					width="200"></el-table-column>
				<el-table-column prop="credit" label="周学时" header-align="center" align="center"
					width="100"></el-table-column>
				<el-table-column prop="totalHours" label="授课学时" header-align="center" align="center"
					width="100"></el-table-column>
				<el-table-column prop="category" label="实验学时" header-align="center" align="center"
					width="100"></el-table-column>
				<el-table-column prop="type" label="课程类别" header-align="center" align="center" width="100">
					<template v-slot="scope">
						{{ getDictLabel("course_type", scope.row.type) }}
					</template>
				</el-table-column>
				<el-table-column prop="language" label="课程性质" header-align="center" align="center" width="100">
					<template v-slot="scope">
						{{ getDictLabel("language_type", scope.row.language) }}
					</template>
				</el-table-column>
				<el-table-column prop="isExperiment" label="是否生成课内实验课" header-align="center" align="center" width="200">
					<template v-slot="scope">
						{{ getDictLabel("yesOrNo", scope.row.isExperiment) }}
					</template>
				</el-table-column>

				<el-table-column prop="status" label="状态" header-align="center" align="center" width="100">
					<template v-slot="scope">
						{{ getDictLabel("verify_status", scope.row.status) }}
					</template>
				</el-table-column>
				<!-- <el-table-column prop="createDate" label="创建时间" header-align="center" align="center"></el-table-column> -->
				<el-table-column :label="$t('handle')" fixed="right" header-align="center" align="center" width="150">
					<template v-slot="scope">
						<el-button v-if="hasPermission('plan:planrecord:save')" type="text" size="small"
							@click="multiAuditHandle()">审核</el-button>
						<el-button v-if="hasPermission('plan:planrecord:save')" type="text" size="small"
							@click="editHandle(scope.row.id)">详情</el-button>
						<el-button v-if="hasPermission('plan:planrecord:delete')" type="text" size="small"
							@click="deleteHandle(scope.row.id)">{{ $t("delete") }}</el-button>
					</template>
				</el-table-column>
			</el-table>
			<!-- 审核弹窗 -->
			<vertify-dialog v-if="vertifyVisible" ref="vertifyDialogRef" @comfirm="comfirmVertify"></vertify-dialog>
		</div>
	</div>
</template>

<script lang="ts">
	import baseService from "@/service/baseService";
	import { IObject } from "@/types/interface";
	import useView from "@/hooks/useView";
	import { defineComponent, reactive, toRefs } from "vue";
	import AddOrUpdate from "./groupcourse-add-or-update.vue";
	import { registerDynamicToRouterAndNext } from "@/router";
	import VertifyDialog from "../dialog/vertify-dialog.vue";
	export default defineComponent({
		components: {
			VertifyDialog
		},
		props: {

		},
		setup() {
			const state = reactive({
				getDataListURL: "/plan/planrecord/page",
				getDataListIsPage: true,
				exportURL: "/plan/planrecord/export",
				deleteURL: "/plan/planrecord",
				routeName: '/plan-planDetail-edit',
				routePath: '/plan/planDetail-edit',
				routeTitle: '教学计划生成管理',
				deleteIsBatch: true,
				vertifyVisible: false,
				dataForm: {
					id: "",
					grade: "",
					institute: "",
					instituteNo: "",
					major: "",
					majorDirection: "",
					name: "",
					eduSystem: "",
					startGrade: "",
					startTerm: "",
					termType: "",
					courseType: "",
					scoreMin: "",
					academicDegree: "",
					trainObjective: "",
					readingRequirements: "",
					programFeatures: "",
					majorDisciplines: "",
					mainCourses: "",
					mainProfessionalExperiments: "",
					status: 0,
					creator: "",
					createDate: "",
					updater: "",
					updateDate: ""
				} as IObject
			});
			return { ...useView(state), ...toRefs(state) };
		},
		watch: {

		},
		methods: {
			init(data) {
				this.dataForm = data;
				console.log(this.dataForm);
			},
			detailHandle(data : IObject) {
				console.log("data", data);
				const routeParams = {
					routeName: `programme-casedetail__${data.id ? data.id : 0}`,
					title: `${data.name} - 详情`,
					path: `/programme/casedetail`,
					query: {
						id: data.id ? data.id : 0,
						_mt: `${data.name} - 详情`
					}
				};
				registerDynamicToRouterAndNext(routeParams);
			},
			multiAuditHandle() {
				this.vertifyVisible = true;
				this.$nextTick(() => {
					this.$refs.vertifyDialogRef.init();
				});
				console.log("哈哈", this.dataListSelections);
			},
			comfirmVertify(status : number, value : string) {
				console.log("value---", status, value);
				let list = [];
				if (this.dataListSelections.length > 0) {
					// this.dataFormSubmitHandle(status);
					this.dataListSelections.forEach((item, index) => {
						this.dataListSelections[index].status = status;
						this.dataListSelections[index].auditReason = value;
						list.push(this.dataListSelections[index]);
					});
				}
				let postDate = JSON.stringify(list);
				console.log("提交", postDate);
				this.dataFormSubmitHandle(postDate);
			},
			dataFormSubmitHandle(data : any) {
				// baseService.put("/student/changerecord/batchUpdate", data, { dataType: "json" }).then((res) => {
				//   if (res.code !== 0) {
				//     return this.$message.error(res.msg);
				//   }
				//   this.$message.success("批量审核成功");
				//   console.log(res);
				//   this.query();
				// });
			}
		}
	});
</script>

<style scoped lang="scss">
	.mod-left-card {
		width: 100%;
		min-height: calc(100vh - 50px - 40px - 30px - 20px - 55px - 42px - 20px);

		.group-title {
			width: 100%;
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin-top: 0;
		}

		.group-item {
			width: 100%;
			padding: 10px;
			cursor: pointer;
			display: flex;
			align-items: center;
			justify-content: space-between;
		}

		.active {
			background-color: rgba(62, 142, 247, 0.2);
			color: #3E8EF7;
		}

	}

	.null {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 100%;
		height: 100%;
		font-size: 20px;
		font-weight: 100;
		color: grey;
	}
</style>