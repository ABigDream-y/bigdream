<template>
	<div class="edit-card--file">
		<div class="aui-card-header">
			<el-button @click="goBack()"><el-icon>
					<ArrowLeft />
				</el-icon>返回</el-button>
			<el-button type="primary" :loading="loading" @click="dataFormSubmitHandle()">{{ $t("confirm") }}</el-button>
		</div>
		<div class="edit-card__body">
			<el-form :model="dataForm" :rules="dataRule" ref="dataFormRef" @keyup.enter="dataFormSubmitHandle()"
				label-width="120px">
				<el-form-item label="编号" prop="code">
					<el-input :readonly="readonly" v-model="dataForm.code" placeholder="编号"></el-input>
				</el-form-item>
				<el-form-item label="培养方案版本名称" prop="name">
					<el-input :readonly="readonly" v-model="dataForm.name" placeholder="培养方案版本名称"></el-input>
				</el-form-item>
				<el-form-item label="版本号" prop="versionNumber">
					<el-input :readonly="readonly" v-model="dataForm.versionNumber" placeholder="版本号"></el-input>
				</el-form-item>
				<el-form-item label="适用范围" prop="applicableScope">
					<el-input :readonly="readonly" v-model="dataForm.applicableScope" placeholder="适用范围"></el-input>
				</el-form-item>
				<el-form-item label="学制" prop="educationalSystem">
					<el-input :readonly="readonly" v-model="dataForm.educationalSystem" placeholder="学制"></el-input>
				</el-form-item>

				<el-form-item label="授予学位" prop="graduate">
					<ren-select v-if="(type == 'edit' || type == 'add') && !readonly" v-model="dataForm.graduate"
						dict-type="degree_type" placeholder="授予学位"></ren-select>
					<div v-else style="color: grey;">
						{{ dataForm.graduate }}
					</div>
				</el-form-item>

				<el-form-item label="修订时间" prop="revisionTime">
					<el-date-picker type="datetime" placeholder="修订时间" value-format="YYYY-MM-DD HH:mm:ss"
						v-model="dataForm.revisionTime"></el-date-picker>
				</el-form-item>
				<el-form-item label="生效时间" prop="effectiveTime">
					<el-date-picker type="datetime" placeholder="生效时间" value-format="YYYY-MM-DD HH:mm:ss"
						v-model="dataForm.effectiveTime"></el-date-picker>
				</el-form-item>
				<el-form-item label="修订单位" prop="revisedBy">
					<el-input :readonly="readonly" v-model="dataForm.revisedBy" placeholder="修订单位"></el-input>
				</el-form-item>
				<el-form-item label="状态" prop="status">
					<ren-select v-if="(type=='edit') && !readonly" v-model="dataForm.status"
						dict-type="plan_version_status" placeholder="状态"></ren-select>
					<ren-select v-else-if="(type=='add') && !readonly" v-model="dataForm.status"
						dict-type="plan_default_status" placeholder="状态"></ren-select>
					<div v-else style="color: grey;">
						{{ getStatus(dataForm.status) }}
					</div>
				</el-form-item>
			</el-form>
		</div>
	</div>
</template>

<script lang="ts">
	import { useStore } from "vuex";
	import { findIndex } from "lodash";
	import { defineComponent, reactive } from "vue";
	import baseService from "@/service/baseService";
	import { useDebounce } from "@/utils/utils";
	export default defineComponent({
		setup() {
			const store = useStore();
			return reactive({
				store,
				loading: false,
				visible: false,
				dataForm: {
					id: "",
					code: "",
					name: "",
					versionNumber: "",
					applicableScope: "",
					educationalSystem: "",
					graduate: "",
					revisionTime: "",
					effectiveTime: "",
					revisedBy: "",
					status: 0,
					creator: "",
					createDate: "",
					updater: "",
					updateDate: "",
				},
				readonly: true,
				type: ""
			});
		},
		computed: {
			dataRule() {
				return {
					code: [{ required: true, message: this.$t("validate.required"), trigger: "blur" }],
					name: [{ required: true, message: this.$t("validate.required"), trigger: "blur" }],
					versionNumber: [{ required: true, message: this.$t("validate.required"), trigger: "blur" }],
					applicableScope: [{ required: true, message: this.$t("validate.required"), trigger: "blur" }],
				};
			}
		},
		created() {
			this.dataFormSubmitHandle = useDebounce(this.dataFormSubmitHandle);
		},
		activated() {
			this.init();
		},
		watch: {

		},
		methods: {
			init() {
				this.loading = false;
				let id = this.$route.query.id || '';
				if (id && id != '0') {
					this.dataForm.id = id;
					this.type = this.$route.query.type || "detail";
				} else {
					this.type = "add";
					this.readonly = false;
				}
				this.$nextTick(() => {
					this.$refs["dataFormRef"].resetFields();
					if (this.dataForm.id) {
						this.getInfo();
					}
				});
			},
			// 获取信息
			getInfo() {
				baseService.get("/programme/caseversion/" + this.dataForm.id).then((res) => {
					if (res.code !== 0) {
						return this.$message.error(res.msg);
					}
					this.dataForm = res.data;
					if (this.type == "edit" && this.dataForm.status == 0) {
						this.type = "edit";
						this.readonly = false;
						console.log(this.dataForm.status, 1)
					} else if (this.type == "edit" && this.dataForm.status > 0) {
						this.type = "detail";
						this.readonly = true;
						console.log(this.dataForm.status, 2)
					} else if (this.type == "detail" && this.dataForm.status > 0) {
						this.type = "detail";
						this.readonly = true;
						console.log(this.dataForm.status, 3)
					} else if(this.type == "detail" && this.dataForm.status == 0){
						this.type = "edit";
						this.readonly = false;
					} else if (this.type == "add") {
						this.type = "add";
						this.readonly = false;
						this.dataForm = {
							id: "",
							code: "",
							name: "",
							versionNumber: "",
							applicableScope: "",
							educationalSystem: "",
							graduate: "",
							revisionTime: "",
							effectiveTime: "",
							revisedBy: "",
							status: 0,
							creator: "",
							createDate: "",
							updater: "",
							updateDate: "",
						};
					}
				});
			},
			// 表单提交
			dataFormSubmitHandle() {
				this.$refs["dataFormRef"].validate((valid : boolean) => {
					if (!valid) {
						return false;
					}
					this.loading = true;
					(!this.dataForm.id ? baseService.post : baseService.put)("/programme/caseversion", this.dataForm).then((res) => {
						if (res.code !== 0) {
							this.loading = false;
							return this.$message.error(res.msg);
						}
						this.$message({
							message: this.$t("prompt.success"),
							type: "success",
							duration: 500,
							onClose: () => {
								this.loading = false;
								this.goBack()
							}
						});
					});
				});
			},
			goBack() {
				const activeTabName = this.store.state.activeTabName;
				const tabs = this.store.state.tabs;
				let index = findIndex(tabs, (x) => x.value === activeTabName);
				this.store.state.tabs.splice(index, 1);
				this.store.state.activeTabName = this.store.state.tabs[this.store.state.tabs.length - 1].value;
				this.updateClosedTabs([...this.store.state.closedTabs, this.store.state.activeTabName], false);
				this.$router.push(this.store.state.activeTabName);
			},
			updateClosedTabs(closedTabs : any[], isTransform = true) {
				if (isTransform) {
					closedTabs = closedTabs.map((x) => x.value);
				}
				this.store.dispatch({
					type: "updateState",
					payload: {
						closedTabs
					}
				});
			},
			getStatus(status) {
				let text = "待生效";
				if (status == 0) {
					text = "待生效";
				} else if (status == 1) {
					text = "执行中";
				} else if (status == 2) {
					text = "中止";
				} else if (status == 3) {
					text = "废弃";
				}

				return text;
			}
		}
	});
</script>