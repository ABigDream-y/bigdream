<template>
	<div class="task-page">
		<el-row :gutter="20">
			<el-col :span="7">
				<el-card class="institute-el-card" shadow="naver">
					<div class="institute-card">
						<div class="institute-item" :class="dataForm.institute == '' ?'active':''">全部</div>
						<div class="institute-item" :class="dataForm.institute == (index + '') ?'active':''" v-for="(item,index) in 5" :key="index">学院{{index + 1}}</div>
					</div>
				</el-card>
			</el-col>
			<el-col :span="17">
				<h3>行政班信息</h3>
				<adminclass></adminclass>
				<h3>教学班信息</h3>
				<!-- <teachingclass></teachingclass> -->
				<teaching></teaching>
			</el-col>
		</el-row>
	</div>
</template>

<style scoped lang="scss">
	.task-page {
		
		:deep(.institute-el-card .el-card__body) {
			padding-top:10px;
			padding-bottom:10px;
			padding:10px;
		}
		
		.institute-card {
			width:100%;
			height:calc(100vh - 50px - 40px - 30px - 42px - 22px);
			overflow: hidden;
			overflow-y: auto;
			
			.institute-item {
				padding:10px 10px;
				cursor:pointer;
				
				&:hover {
					background-color: rgba(62, 142, 247, 0.2);
					color: #3E8EF7;
				}
			}
			
			.active {
				background-color: rgba(62, 142, 247, 0.2);
				color: #3E8EF7;
			}
		}
	}
</style>

<script lang="ts">
	import { defineComponent, reactive, toRefs } from "vue";
	import adminclass from "./adminclass.vue";
	import teachingclass from "./teachingclass.vue";
	import teaching from "./teaching.vue";
	export default defineComponent({
		components: {
			adminclass,
			teachingclass,
			teaching
		},
		setup() {
			const state = reactive({
				instituteList:[],
				dataForm:{
					institute:""
				}
			});
			return { ...toRefs(state) };
		},
		methods: {

		}

	});
</script>