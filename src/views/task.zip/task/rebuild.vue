<template>
	<div class="task-page">
		
	</div>
</template>

<script lang="ts">
	import { defineComponent, reactive, toRefs } from "vue";
	export default defineComponent({
		setup() {
			const state = reactive({

			});
			return { ...toRefs(state) };
		},
		methods:{
			
		}
		
	});
</script>