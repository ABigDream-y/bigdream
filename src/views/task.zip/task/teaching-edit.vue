<template>
	<div class="edit-card--file edit-card-page">
		<div class="aui-card-header ">
			<el-button @click="goBack()"><el-icon>
					<ArrowLeft />
				</el-icon>返回</el-button>
			<el-button type="primary" :loading="loading" @click="dataFormSubmitHandle()">{{ $t("confirm") }}</el-button>
		</div>
		<div class="edit-card__body">
			<el-form :model="dataForm" :rules="dataRule" ref="dataFormRef" @keyup.enter="dataFormSubmitHandle()"
				label-width="120px">
				<el-row :gutter="20">
					<el-col :span="24">
						<h3 class="info-h3">
							<span style="margin-right:15px;">课基本信息</span>
						</h3>
					</el-col>
					<!-- <el-form-item label="状态" prop="status">
						<ren-radio-group v-model="dataForm.status" dict-type="enable_status"></ren-radio-group>
					</el-form-item> -->
					<el-col :span="24">
						<el-form-item>
							<el-button type="primary" size="large" @click="selectCourse()">选择课程</el-button>
						</el-form-item>
					</el-col>
					<el-col :span="8">
						<el-form-item label="课程号" prop="courseNo">
							<el-input v-model="dataForm.courseNo" readonly size="large" placeholder="课程号"></el-input>
						</el-form-item>
						<el-form-item label="教学方式" prop="teachingMethods">
							<ren-select v-model="dataForm.teachingMethods" disabled size="large" dict-type="course_mode"
								placeholder="教学方式"></ren-select>
						</el-form-item>
						<el-form-item label="总学时" prop="totalHours">
							<el-input v-model="dataForm.totalHours" readonly size="large" placeholder="总学时"></el-input>
						</el-form-item>
						<el-form-item label="实验学时" prop="practicalHours">
							<el-input v-model="dataForm.practicalHours" readonly size="large"
								placeholder="实验学时"></el-input>
						</el-form-item>
					</el-col>
					<el-col :span="8">
						<el-form-item label="课程名" prop="courseName">
							<el-input v-model="dataForm.courseName" readonly size="large" placeholder="课程名"></el-input>
						</el-form-item>
						<!-- <el-form-item label="课程负责人" prop="courseHead">
							<el-input v-model="dataForm.courseHead" readonly size="large" placeholder="课程负责人"></el-input>
						</el-form-item> -->
						<el-form-item label="授课学时" prop="teachingHours">
							<el-input v-model="dataForm.teachingHours" readonly size="large"
								placeholder="授课学时"></el-input>
						</el-form-item>
						<el-form-item label="上机学时" prop="computerHours">
							<el-input v-model="dataForm.computerHours" readonly size="large"
								placeholder="上机学时"></el-input>
						</el-form-item>
						<el-form-item label="其他学时" prop="otherHours">
							<el-input v-model="dataForm.otherHours" readonly size="large" placeholder="其他学时"></el-input>
						</el-form-item>
					</el-col>
					<el-col :span="8">
						<el-form-item label="开课单位" prop="courseUnit">
							<el-input v-model="dataForm.courseUnit" readonly size="large" placeholder="开课单位"></el-input>
						</el-form-item>
						<el-form-item label="学分" prop="score">
							<el-input v-model="dataForm.score" readonly size="large" placeholder="学分"></el-input>
						</el-form-item>
						<el-form-item label="周学时" prop="weekHours">
							<el-input v-model="dataForm.weekHours" readonly size="large" placeholder="周学时"></el-input>
						</el-form-item>

					</el-col>
					<el-col :span="24">
						<h3 class="info-h3">任务信息</h3>
					</el-col>
					<el-col :span="8">
						<el-form-item label="预计重修人数" prop="expectedRefurbishment">
							<el-input v-model="dataForm.expectedRefurbishment" size="large"
								placeholder="预计重修人数"></el-input>
						</el-form-item>
					</el-col>
					<el-col :span="8">
						<el-form-item label="课容量" prop="courseNumber">
							<el-input v-model="dataForm.courseNumber" size="large" placeholder="课容量"></el-input>
						</el-form-item>
					</el-col>
					<el-col :span="24">
						<h3 class="info-h3">场地要求</h3>
					</el-col>
					<el-col :span="8">
						<el-form-item label="需求" prop="requirement">
							<el-select v-model="dataForm.requirement" size="large">
								<el-option :value="1" label="需要"></el-option>
								<el-option :value="0" label="不需要"></el-option>
							</el-select>
						</el-form-item>
						<el-form-item label="校区" prop="campus">
							<el-input v-model="dataForm.campus" size="large" placeholder="校区"></el-input>
						</el-form-item>
						<el-form-item label="教室" prop="classroom">
							<el-input v-model="dataForm.classroom" size="large" placeholder="教室"></el-input>
						</el-form-item>
					</el-col>
					<el-col :span="8">
						<el-form-item label="教室类型" prop="classroomType">
							<ren-select-data size="large" v-model="dataForm.classroomType" placeholder="场地类型" selectLabel="name"
								selectValue="id" dataUrl="/resource/teachingareatype/page"></ren-select-data>
							<!-- <el-input v-model="dataForm.classroomType" size="large" placeholder="教室类型"></el-input> -->
						</el-form-item>
						<el-form-item label="教学楼" prop="building">
							<el-input v-model="dataForm.building" size="large" placeholder="教学楼"></el-input>
						</el-form-item>
					</el-col>
					<!-- <el-form-item label="场地id" prop="areaId">
						<el-input v-model="dataForm.areaId" placeholder="场地id"></el-input>
					</el-form-item> -->
					<el-col :span="24">
						<h3 class="info-h3">限制</h3>
					</el-col>
					<el-col :span="8">
						<el-form-item label="是否有性别限制" prop="genderStatus">
							<ren-radio-group v-model="dataForm.genderStatus" size="large"
								dict-type="yesOrNo"></ren-radio-group>
						</el-form-item>
					</el-col>
					<el-col :span="8">
						<el-form-item label="男生人数" prop="maleNum">
							<el-input-number v-model="dataForm.maleNum" size="large" placeholder="男生人数"
								:min="0"></el-input-number>
						</el-form-item>
					</el-col>
					<el-col :span="8">
						<el-form-item label="女生人数" prop="femaleNum">
							<el-input-number v-model="dataForm.femaleNum" size="large" placeholder="女生人数"
								:min="0"></el-input-number>
						</el-form-item>
					</el-col>
					<el-col :span="24">
						<el-form-item label="备注" prop="remark">
							<el-input type="textarea" :rows="5" v-model="dataForm.remark" size="large"></el-input>
						</el-form-item>
						<el-form-item label="选课说明" prop="description">
							<el-input type="textarea" :rows="5" v-model="dataForm.description" size="large"></el-input>
						</el-form-item>
					</el-col>
					<el-col :span="24">
						<h3 class="info-h3">上课周次</h3>
					</el-col>
					<el-col :span="24">
						<el-form-item label="上课周次" prop="courseCount">
							<el-input v-model="dataForm.courseCount" size="large" placeholder="上课周次"></el-input>
						</el-form-item>

					</el-col>
					<el-col :span="24">
						<h3 class="info-h3">时间要求</h3>
					</el-col>
					<el-col :span="8">
						<el-form-item label="时间要求" prop="courseTimeRequire">
							<el-input v-model="dataForm.courseTimeRequire" size="large" placeholder="时间要求"></el-input>
						</el-form-item>
					</el-col>

					<el-col :span="24" v-if="dataForm.id">
						<h3 class="info-h3">上课班级</h3>
						<teaching-clasess ref="teachingClasess" :teaching="dataForm.id"></teaching-clasess>
					</el-col>
					<el-col :span="24" v-if="dataForm.id">
						<h3>上课教师</h3>
						<teaching-teacher ref="teachingTeacher" :teaching="dataForm.id"></teaching-teacher>
					</el-col>
				</el-row>
			</el-form>
		</div>
		<course-dialog v-if="courseVisible" ref="courseDialog" @confirm="confirmCourse"></course-dialog>
	</div>
</template>

<script lang="ts">
	import { IObject } from "@/types/interface";
	import { useStore } from "vuex";
	import { findIndex } from "lodash";
	import { defineComponent, reactive } from "vue";
	import baseService from "@/service/baseService";
	import { useDebounce } from "@/utils/utils";
	import TeachingClasess from "./teachingclasess.vue";
	import TeachingTeacher from "./teachingteacher.vue";
	import CourseDialog from "../dialog/course.vue";
	export default defineComponent({
		components: {
			TeachingClasess,
			TeachingTeacher,
			CourseDialog
		},
		setup() {
			const store = useStore();
			return reactive({
				store,
				loading: false,
				visible: false,
				courseVisible: false,
				dataForm: {
					id: "",
					courseNo: "",
					courseName: "",
					courseUnit: "",
					status: "",
					teachingMethods: "",
					courseHead: "",
					score: "",
					totalHours: "",
					teachingHours: "",
					weekHours: "",
					practicalHours: "",
					computerHours: "",
					otherHours: "",
					campus: "",
					courseNumber: "",
					expectedRefurbishment: "",
					requirement: "",
					classroomType: "",
					areaId: "",
					building: "",
					classroom: "",
					genderStatus: 0,
					maleNum: "",
					femaleNum: "",
					remark: "",
					description: "",
					courseCount: "",
					courseTimeRequire: "",
					creator: "",
					createDate: "",
					updater: "",
					updateDate: "",
				} as IObject
			});
		},
		computed: {
			dataRule() {
				return {
					courseName: [{ required: true, message: this.$t("validate.required"), trigger: "blur" }],
				};
			}
		},
		created() {
			this.dataFormSubmitHandle = useDebounce(this.dataFormSubmitHandle);
		},
		activated() {
			this.init();
		},
		methods: {
			init() {
				this.loading = false;
				let id = this.$route.query.id || '';
				if (id && id != '0') {
					this.dataForm.id = id;
				}
				this.$nextTick(() => {
					this.$refs["dataFormRef"].resetFields();
					if (this.dataForm.id) {
						this.$refs.teachingClasess.init(this.dataForm.id);
						this.$refs.teachingTeacher.init(this.dataForm.id);
						this.getInfo();
					}
				});
			},
			// 获取信息
			getInfo() {
				baseService.get("/task/teaching/" + this.dataForm.id).then((res) => {
					if (res.code !== 0) {
						return this.$message.error(res.msg);
					}
					this.dataForm = res.data;
				});
			},
			selectCourse() {
				this.courseVisible = true;
				this.$nextTick(() => {
					this.$refs.courseDialog.init();
				})
			},
			confirmCourse(data : IObject) {
				console.log('data', data);
				this.dataForm.courseNo = data.code;
				this.dataForm.courseName = data.name;
				this.dataForm.courseUnit = data.unit;
				this.dataForm.teachingMethods = data.mode;
				this.dataForm.score = data.credit;
				this.dataForm.totalHours = data.totalHours;
				this.dataForm.teachingHours = data.teachingHours;
				this.dataForm.weekHours = data.weekHours;
				this.dataForm.practicalHours = data.practicalHours;
				this.dataForm.computerHours = data.computerHours;
				this.dataForm.otherHours = data.otherHours;
			},
			// 表单提交
			dataFormSubmitHandle() {
				this.$refs["dataFormRef"].validate((valid : boolean) => {
					if (!valid) {
						return false;
					}
					this.loading = true;
					(!this.dataForm.id ? baseService.post : baseService.put)("/task/teaching", this.dataForm).then((res) => {
						if (res.code !== 0) {
							this.loading = false;
							return this.$message.error(res.msg);
						}
						this.$message({
							message: this.$t("prompt.success"),
							type: "success",
							duration: 500,
							onClose: () => {
								this.loading = false;
								this.goBack()
							}
						});
					});
				});
			},
			goBack() {
				const activeTabName = this.store.state.activeTabName;
				const tabs = this.store.state.tabs;
				let index = findIndex(tabs, (x) => x.value === activeTabName);
				this.store.state.tabs.splice(index, 1);
				this.store.state.activeTabName = this.store.state.tabs[this.store.state.tabs.length - 1].value;
				this.updateClosedTabs([...this.store.state.closedTabs, this.store.state.activeTabName], false);
				this.$router.push(this.store.state.activeTabName);
			},
			updateClosedTabs(closedTabs : any[], isTransform = true) {
				if (isTransform) {
					closedTabs = closedTabs.map((x) => x.value);
				}
				this.store.dispatch({
					type: "updateState",
					payload: {
						closedTabs
					}
				});
			}
		}
	});
</script>